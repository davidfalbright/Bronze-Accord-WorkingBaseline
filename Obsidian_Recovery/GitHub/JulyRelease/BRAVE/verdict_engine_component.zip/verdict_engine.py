# verdict_engine.py

from yaml_enforcer import enforce_yaml
from fallback_handler import handle_fallback
from verdict_logger import log_verdict

def evaluate_action(input_data):
    try:
        # Step 1: Enforce YAML constraints
        enforcement_result = enforce_yaml(input_data)

        # Step 2: If no clear result, apply fallback logic
        if enforcement_result.get("verdict") == "undetermined":
            enforcement_result = handle_fallback(input_data)

        # Step 3: Log the outcome
        log_verdict(enforcement_result)

        return enforcement_result

    except Exception as e:
        return {
            "verdict": "error",
            "error_detail": str(e),
            "input": input_data
        }
