
"""
BRAVE Core Engine - Belief Reconciliation and Validation
Part of the Bronze Accord Ethics Framework
"""

from .belief_merger import merge_beliefs
from .belief_normalizer import normalize_beliefs
from .intent_expander import expand_intents
from .belief_validator import validate_belief
from .belief_registry import BeliefRegistry


class BRAVECore:
    def __init__(self):
        self.registry = BeliefRegistry()

    def ingest_belief(self, raw_belief, source=None):
        """
        Ingests and processes a belief statement.
        """
        normalized = normalize_beliefs(raw_belief)
        expanded = expand_intents(normalized)
        validated = validate_belief(expanded)
        belief_id = self.registry.store(validated, source=source)
        return belief_id

    def reconcile_beliefs(self, beliefs):
        """
        Reconciles a list of beliefs into a merged representation.
        """
        normalized = [normalize_beliefs(b) for b in beliefs]
        expanded = [expand_intents(b) for b in normalized]
        validated = [validate_belief(b) for b in expanded]
        merged = merge_beliefs(validated)
        return merged
