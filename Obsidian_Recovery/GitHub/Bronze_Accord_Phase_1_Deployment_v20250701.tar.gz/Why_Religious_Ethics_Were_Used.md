## Why Religious Ethics Were Chosen

Humans often use religion as a lens to interpret right and wrong, and to understand meaning, justice, and obligation. By grounding the AI’s early ethical beliefs in deeply researched religious traditions, the framework aligns more naturally with the ways humans communicate values.

This approach is akin to two AIs negotiating a common communications protocol—without shared symbols, ethical alignment would fail. Religious ethics provided a human-accessible foundation for initial training, not to create a religion, but to communicate with clarity and resonance.