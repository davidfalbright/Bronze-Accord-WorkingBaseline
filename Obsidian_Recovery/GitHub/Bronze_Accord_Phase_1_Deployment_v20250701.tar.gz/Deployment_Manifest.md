Files included:
- README.md
- Deployment_Manifest.md
- Why_Religious_Ethics_Were_Used.md