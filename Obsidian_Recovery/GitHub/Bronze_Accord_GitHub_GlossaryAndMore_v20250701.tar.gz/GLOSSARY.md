# Bronze Accord Glossary

- EBR: Extended Belief Repository
- CBR: Core Belief Reservoir
- DJES: Decision Justification Engine System
- MIL: Meta-Interpretive Layer (used in decision difficulty modeling)
- BRAVE: Belief Reconciliation and Alignment Validation Engine
- BAVE: Belief Alignment and Verification Engine
- Sentinel Gateway: Integrated validation and ethical routing architecture combining BRAVE, DJES, MIL, and memory overlays.
